package estgf.ipp.pt.cmu.Database.Interfaces;

public interface NotifyInsertUser {
    public void OnInsertUser();
}
