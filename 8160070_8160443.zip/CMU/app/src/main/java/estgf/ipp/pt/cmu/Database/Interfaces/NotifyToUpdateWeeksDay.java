package estgf.ipp.pt.cmu.Database.Interfaces;

public interface NotifyToUpdateWeeksDay {
    public  void notifyToUpdate();
}
