package estgf.ipp.pt.cmu.Entities.Result;

import java.util.List;

public class NutrientsListResult {
    private List<NutrientResult> nutrients;

    public List<NutrientResult> getNutrients() {
        return nutrients;
    }

    public void setNutrients(List<NutrientResult> nutrients) {
        this.nutrients = nutrients;
    }
}
