package estgf.ipp.pt.cmu.Utilities;

public interface OnFoodAdded {
    public void notifySumCalories(int calories);
}
