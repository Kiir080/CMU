package estgf.ipp.pt.cmu.Entities.Result;

public enum ResultType {
    Ingredient,Product,Recipe
}
