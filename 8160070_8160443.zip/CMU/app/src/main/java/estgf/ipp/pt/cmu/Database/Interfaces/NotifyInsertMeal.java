package estgf.ipp.pt.cmu.Database.Interfaces;

public interface NotifyInsertMeal {
    public void OnInsertMeal();
}
