package estgf.ipp.pt.cmu.Database.Interfaces;

import estgf.ipp.pt.cmu.Entities.Meal.Meal;

public interface NotifyGetMeal {
    public void GetMeal(Meal meal);
}
