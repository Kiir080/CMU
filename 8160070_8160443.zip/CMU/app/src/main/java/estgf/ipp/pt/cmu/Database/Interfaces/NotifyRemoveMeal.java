package estgf.ipp.pt.cmu.Database.Interfaces;

import estgf.ipp.pt.cmu.Entities.Meal.Meal;

public interface NotifyRemoveMeal {
    public void OnRemoveMeal();
}
