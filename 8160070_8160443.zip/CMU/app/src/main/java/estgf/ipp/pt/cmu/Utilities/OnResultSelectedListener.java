package estgf.ipp.pt.cmu.Utilities;

import estgf.ipp.pt.cmu.Entities.Result.Result;

public interface OnResultSelectedListener {

    public void onResultSelected(Result result);
}
