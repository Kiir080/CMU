package estgf.ipp.pt.cmu.Entities.Meal;

public class Meal {

    public String Name;

    public Meal(String name){
        this.Name=name;

    }
}
