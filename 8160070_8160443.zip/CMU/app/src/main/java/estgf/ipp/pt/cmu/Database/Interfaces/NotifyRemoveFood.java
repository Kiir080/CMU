package estgf.ipp.pt.cmu.Database.Interfaces;

public interface NotifyRemoveFood {
    public void OnRemoveFood();
}
