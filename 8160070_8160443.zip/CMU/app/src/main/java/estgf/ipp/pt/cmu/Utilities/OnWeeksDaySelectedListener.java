package estgf.ipp.pt.cmu.Utilities;

import estgf.ipp.pt.cmu.Entities.Food.Ingredient;
import estgf.ipp.pt.cmu.Entities.Food.Product;
import estgf.ipp.pt.cmu.Entities.Food.Recipe;
import estgf.ipp.pt.cmu.Entities.WeeksDays.WeeksDays;

public interface OnWeeksDaySelectedListener {
    public void onWeeksDaySelected(WeeksDays weeksDay);
}
