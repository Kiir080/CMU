package estgf.ipp.pt.cmu.Utilities;

import estgf.ipp.pt.cmu.Entities.Food.Food;

public interface NotifyGetFoodInformation {
    public void OnGetFoodInformation(Food food);
}
