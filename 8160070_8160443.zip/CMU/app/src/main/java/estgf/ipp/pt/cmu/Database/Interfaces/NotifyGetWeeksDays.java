package estgf.ipp.pt.cmu.Database.Interfaces;

import java.util.List;

import estgf.ipp.pt.cmu.Entities.WeeksDays.WeeksDays;

public interface NotifyGetWeeksDays {
    public void OnGetWeeksDays(List<WeeksDays> list);
}
