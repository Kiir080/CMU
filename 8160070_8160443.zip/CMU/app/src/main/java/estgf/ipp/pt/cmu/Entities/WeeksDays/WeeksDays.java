package estgf.ipp.pt.cmu.Entities.WeeksDays;

class WeeksDays {
}
