package estgf.ipp.pt.cmu.Utilities;

import estgf.ipp.pt.cmu.Entities.Meal.Meal;

public interface OnMealSelectedListener {

    public void onMealSelected(Meal meal);

    public void onMealLongPressed(Meal meal);
}
