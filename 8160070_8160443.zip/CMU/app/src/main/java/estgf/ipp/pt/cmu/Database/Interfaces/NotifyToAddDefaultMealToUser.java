package estgf.ipp.pt.cmu.Database.Interfaces;

import estgf.ipp.pt.cmu.Entities.Meal.Meal;
import estgf.ipp.pt.cmu.Entities.User.User;

public interface NotifyToAddDefaultMealToUser {
    public void OnAddDefaultMealToUser(Meal meal);
}
